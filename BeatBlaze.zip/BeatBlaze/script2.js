const playBtn = document.getElementById('play-btn');
let isPlaying = false;

playBtn.addEventListener('click', () => {
    if (!isPlaying) {
        // Aqui você colocaria o código para tocar a música
        console.log('Playing music...');
        isPlaying = true;
    } else {
        // Aqui você colocaria o código para pausar a música
        console.log('Pausing music...');
        isPlaying = false;
    }
});
