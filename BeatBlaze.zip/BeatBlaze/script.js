    // Função para controlar a reprodução da música
    function togglePlay() {
        var audio = document.getElementById('audio');
        var playButton = document.querySelector('.play-button img');
        
        if (audio.paused) {
            audio.play();  // Reproduz a música
            playButton.src = 'imgs/pause.png'; // Muda para o ícone de pausa
        } else {
            audio.pause(); // Pausa a música
            playButton.src = 'imgs/play.png';  // Muda para o ícone de play
        }
    }

    // Adiciona um evento de erro, caso a música não consiga ser carregada
    document.getElementById('audio').addEventListener('error', function() {
        alert("Erro ao carregar a música. Verifique o arquivo de áudio.");
    });