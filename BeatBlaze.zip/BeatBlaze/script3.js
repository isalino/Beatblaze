let isPlaying = false;
const audio = document.querySelector(".music-audio"); // Seleciona o elemento de áudio
const waves = document.querySelectorAll(".wave"); // Seleciona todas as ondas
const playButton = document.querySelector(".play-button"); // Seleciona o botão de play

playButton.addEventListener("click", () => {
  isPlaying = !isPlaying; // Alterna entre play e pause

  if (isPlaying) {
    audio.play(); // Toca a música
    waves.forEach((wave) => {
      wave.style.animationPlayState = "running"; // Inicia a animação das ondas
    });
    playButton.textContent = "⏸"; // Troca o ícone para pause
  } else {
    audio.pause(); // Pausa a música
    waves.forEach((wave) => {
      wave.style.animationPlayState = "paused"; // Pausa a animação das ondas
    });
    playButton.textContent = "▶"; // Troca o ícone para play
  }
});
