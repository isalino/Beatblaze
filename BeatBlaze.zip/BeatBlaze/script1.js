// Função para tocar o áudio
function playAudio(audioId, button) {
    const audio = document.getElementById(audioId);
    const playBtn = button.querySelector("img");

    // Pausar todos os áudios
    const allAudios = document.querySelectorAll("audio");
    allAudios.forEach(a => {
        if (a !== audio) {
            a.pause();
        }
    });

    if (audio.paused) {
        audio.play();
        playBtn.src = "imgs/pause.png"; // Ícone de pause
    } else {
        audio.pause();
        playBtn.src = "imgs/plaus.png"; // Ícone de play
    }
}

// Função para alternar entre os slides
let currentSlideIndex = 0;

const slides = document.querySelectorAll('.carousel-item');
const totalSlides = slides.length;

const prevButton = document.querySelector('.prev');
const nextButton = document.querySelector('.next');

function showSlide(index) {
    // Ocultar todos os slides
    slides.forEach(slide => slide.classList.remove('active'));

    // Exibir o slide atual
    slides[index].classList.add('active');

    // Pausar todos os áudios e tocar o áudio do slide atual
    const currentAudio = slides[index].querySelector("audio");
    const allAudios = document.querySelectorAll("audio");
    
    allAudios.forEach(audio => {
        if (audio !== currentAudio) {
            audio.pause(); // Pausa todos os outros áudios
        }
    });

    // Iniciar o áudio do slide atual
    if (currentAudio) {
        currentAudio.play();
    }
}

// Avançar para o próximo slide
nextButton.addEventListener('click', () => {
    currentSlideIndex = (currentSlideIndex + 1) % totalSlides; // Avança para o próximo slide
    showSlide(currentSlideIndex);
});

// Voltar para o slide anterior
prevButton.addEventListener('click', () => {
    currentSlideIndex = (currentSlideIndex - 1 + totalSlides) % totalSlides; // Volta para o slide anterior
    showSlide(currentSlideIndex);
});

// Mostrar o primeiro slide por padrão
showSlide(currentSlideIndex);
